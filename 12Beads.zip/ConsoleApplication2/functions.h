#pragma once
void grid(int [][5]);
int toss();
void rendercircle(int[][5],int,bool);
bool working(int[5][5],int,int,int,int,int);
int menu(int [][5]);
void win(int);
int main();