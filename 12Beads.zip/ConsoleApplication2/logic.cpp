#include<iostream>
#include<SFML/Graphics.hpp>
using namespace sf;
using namespace std;
bool working(int arr[][5],int indexfromx,int indexfromy,int indextox,int indextoy,int turn)
{
	bool success = 0;
	int temp;
	Vector2i indexfrom, indexto;
	indexfrom.x = indexfromx;
	indexfrom.y = indexfromy;
	indexto.x = indextox;
	indexto.y = indextoy;
	/*cout << "Enter index from:";
	cin >> indexfrom.x;
	cin >> indexfrom.y;
	cout << "Enter index to:";
	cin >> indexto.x;
	cin >> indexto.y;*/
	if (arr[indexfrom.x][indexfrom.y] == turn)
	{
		if (arr[indexto.x][indexto.y] == 0)
		{
			if (indexto.x == indexfrom.x - 1 || indexto.x == indexfrom.x + 1 || indexto.y == indexfrom.y - 1 || indexto.y == indexfrom.y + 1)
			{
				if (((indexfrom.x % 2 == 1 && indexfrom.y % 2 == 0) || (indexfrom.x % 2 == 0 && indexfrom.y % 2 == 1)) && ((indexto.x % 2 == 0 && indexto.y % 2 == 1) || (indexto.x % 2 == 1 && indexto.y % 2 == 0)))
				{
					if (indexfrom.x == indexto.x || indexfrom.y == indexto.y)
					{
						temp = arr[indexfrom.x][indexfrom.y];
						arr[indexfrom.x][indexfrom.y] = arr[indexto.x][indexto.y];
						arr[indexto.x][indexto.y] = temp;
						if ((indexfrom.x + indexto.x) % 2 == 0 && (indexfrom.y + indexto.y) % 2 == 0)
						{
							arr[(indexfrom.x + indexto.x) / 2][(indexfrom.y + indexto.y) / 2] = 0;
						}
						success = 1;
					}
					else
						cout << " ";
				}
				else
				{
					temp = arr[indexfrom.x][indexfrom.y];
					arr[indexfrom.x][indexfrom.y] = arr[indexto.x][indexto.y];
					arr[indexto.x][indexto.y] = temp;
					if ((indexfrom.x + indexto.x) % 2 == 0 && (indexfrom.y + indexto.y) % 2 == 0)
					{
						arr[(indexfrom.x + indexto.x) / 2][(indexfrom.y + indexto.y) / 2] = 0;
					}
					success = 1;
				}
			}
			else if (arr[indexfrom.x][indexfrom.y] == -arr[indexfrom.x - 1][indexfrom.y] || arr[indexfrom.x][indexfrom.y] == -arr[indexfrom.x + 1][indexfrom.y] || arr[indexfrom.x][indexfrom.y] == -arr[indexfrom.x][indexfrom.y - 1] || arr[indexfrom.x][indexfrom.y] == -arr[indexfrom.x][indexfrom.y + 1] || arr[indexfrom.x][indexfrom.y] == -arr[indexfrom.x - 1][indexfrom.y - 1] || arr[indexfrom.x][indexfrom.y] == -arr[indexfrom.x + 1][indexfrom.y + 1] || arr[indexfrom.x][indexfrom.y] == -arr[indexfrom.x - 1][indexfrom.y + 1] || arr[indexfrom.x][indexfrom.y] == -arr[indexfrom.x + 1][indexfrom.y - 1])
			{
				if (arr[(indexfrom.x + indexto.x) / 2][(indexfrom.y + indexto.y) / 2] != 0)
				if (((indexfrom.x % 2 == 1 && indexfrom.y % 2 == 0) || (indexfrom.x % 2 == 0 && indexfrom.y % 2 == 1)) && ((indexto.x % 2 == 0 && indexto.y % 2 == 1) || (indexto.x % 2 == 1 && indexto.y % 2 == 0)))
				{
					if (indexfrom.x == indexto.x || indexfrom.y == indexto.y)
					{
						temp = arr[indexfrom.x][indexfrom.y];
						arr[indexfrom.x][indexfrom.y] = arr[indexto.x][indexto.y];
						arr[indexto.x][indexto.y] = temp;
						if ((indexfrom.x + indexto.x) % 2 == 0 && (indexfrom.y + indexto.y) % 2 == 0)
						{
							arr[(indexfrom.x + indexto.x) / 2][(indexfrom.y + indexto.y) / 2] = 0;
						}
						success = 1;
					}
					else
						cout << " ";
				}
				else
				{
					temp = arr[indexfrom.x][indexfrom.y];
					arr[indexfrom.x][indexfrom.y] = arr[indexto.x][indexto.y];
					arr[indexto.x][indexto.y] = temp;
					if ((indexfrom.x + indexto.x) % 2 == 0 && (indexfrom.y + indexto.y) % 2 == 0)
					{
						arr[(indexfrom.x + indexto.x) / 2][(indexfrom.y + indexto.y) / 2] = 0;
					}
					success = 1;
				}
			}
			else
				cout << " ";

		}
		else
			cout << " ";
	}
	return success;
}