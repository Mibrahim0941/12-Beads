#include<iostream>
#include<conio.h>
#include"functions.h"
#include<fstream>
using namespace std;
int main()
{
    int resume;
    char ch;
    int board[5][5] = { 0 }, i, j, turn=0;
    bool temp=1;
    //grid(board);
    resume=menu(board);
    if (resume == 2)
    {
        ifstream resume;
        resume.open("resume.txt");
        for (i = 0; i < 5; i++)
        {
            for (j = 0; j < 5; j++)
            {
                resume >> board[i][j];
            }
        }
        resume >> turn >> temp;
        resume.close();
    }
    else if (resume == 1)
        grid(board);
    else
        exit(0);
    rendercircle(board,turn,temp);
    return 0;
}