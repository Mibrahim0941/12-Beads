#include"SFML/Graphics.hpp"
#include<SFML/Audio.hpp>
#include"functions.h"
#include<iostream>
#include<fstream>
using namespace std;
using namespace sf;
void rendercircle(int arr[][5],int tosss,bool tossoncetext)
{
	bool flag = 0 ;
	bool tossflag = 1, success;
	int whowon;
	int i = 0,j = 0,temp,turn;
	//turn = toss();
	RenderWindow window(VideoMode(1600, 900), "12 beads");
	
	window.setSize(Vector2u(1600, 900));
	Texture texturetoss,bead1,bead2,textureP1win,textureP2win,P1,P2;
	texturetoss.loadFromFile("asset.png");
	textureP1win.loadFromFile("p1toss.png");
	textureP2win.loadFromFile("p2toss.png");
	P1.loadFromFile("P1.png");
	P2.loadFromFile("P2.png");
	bead1.loadFromFile("red.png");
	bead2.loadFromFile("green.png");
	Sprite backgroundtoss(texturetoss);
	Sprite backgroundtoss1(textureP1win);
	Sprite backgroundtoss2(textureP2win);
	Sprite Player1(P1);
	Sprite Player2(P2);
    CircleShape circle;
	circle.setRadius(20);
	Vector2i indexfrom(0,0), indexto(0,0);
	Music music;
	music.openFromFile("game.mp3");
	music.play();
	music.setLoop(true);
	while (window.isOpen())
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == Event::Closed||event.key.code==Keyboard::Escape)
			{
				ofstream resume;
				resume.open("resume.txt");
				for (int i = 0; i < 5; i++)
				{
					for (int j = 0; j < 5; j++)
					{
						resume << arr[i][j] << " ";
					}
				}
				resume << tosss<<" " << tossoncetext;
				resume.close();
				window.close();
				music.pause();
				main();
			}
		}
		window.clear(Color::White);
		if (tossoncetext)
		{
			if (tosss == -1)
			{
				window.draw(backgroundtoss1);
			}
			else if (tosss == 1)
			{
				window.draw(backgroundtoss2);
			}
			else
				window.draw(backgroundtoss);
		}
		else
		{
			if (tosss == -1)
			{
				window.draw(Player1);
			}
			else if (tosss == 1)
			{
				window.draw(Player2);
			}
		}
		int y = 0;
		for (i = 0; i < 5; i++)
		{
			int x = 0;
			for (j = 0; j < 5; j++)
			{
				if (arr[i][j] == -1)
				{
					Vector2f vect(((j + 1) * (250 - x)) + x, ((i + 1) * (200 - y)) + y);
					//circle.setFillColor(Color::Red);
					circle.setTexture(&bead1);
					circle.setPosition(vect);
					window.draw(circle);
				}
				else if (arr[i][j] == 1)
				{
					Vector2f vect(((j + 1) * (250 - x)) + x, ((i + 1) * (200 - y)) + y);
					circle.setPosition(vect);
					circle.setTexture(&bead2);
					//circle.setFillColor(Color::Green);
					window.draw(circle);
				}
				x = 127;
			}
			y = 80;
		}
		window.display();
		int count1=0, count2 = 0;
		for (i = 0; i < 5; i++)
		{
			for (j = 0; j < 5; j++)
			{
				if (arr[i][j] == -1)
					count1++;
				else if (arr[i][j] == 1)
					count2++;
			}
		}
		if (count1 == 0)
		{
			//cout << "Player 2 Won";
			window.close();
			whowon = 2;
			win(whowon);
		}
		else if (count2 == 0)
		{
			/*cout << "Player1 won";*/
			window.close();
			whowon = 1;
			win(whowon);
		}
		if (event.type == sf::Event::MouseButtonPressed)
		{
			if (event.mouseButton.button == sf::Mouse::Left)
			{
				if (tossflag)
				{
					sf::Vector2i mousePos = sf::Mouse::getPosition(window);
					if ((mousePos.x >= 1000 && mousePos.x <= 1250) && (mousePos.y >= 350 && mousePos.y <= 550))
					{
						tosss = toss();
						flag = 1;
						tossflag = 0;
						continue;
					}
				}
				if (flag)
				{
					sf::Vector2i mousePos = sf::Mouse::getPosition(window);
					if ((mousePos.x >= 215 && mousePos.x <= 285) && (mousePos.y >= 165 && mousePos.y <= 235))
					{
						indexfrom.x = 0;
						indexfrom.y = 0;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 340 && mousePos.x <= 410) && (mousePos.y >= 165 && mousePos.y <= 235))
					{
						indexfrom.x = 0;
						indexfrom.y = 1;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 465 && mousePos.x <= 535) && (mousePos.y >= 165 && mousePos.y <= 235))
					{
						indexfrom.x = 0;
						indexfrom.y = 2;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 590 && mousePos.x <= 660) && (mousePos.y >= 165 && mousePos.y <= 235))
					{
						indexfrom.x = 0;
						indexfrom.y = 3;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 715 && mousePos.x <= 785) && (mousePos.y >= 165 && mousePos.y <= 235))
					{
						indexfrom.x = 0;
						indexfrom.y = 4;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 215 && mousePos.x <= 285) && (mousePos.y >= 290 && mousePos.y <= 360))
					{
						indexfrom.x = 1;
						indexfrom.y = 0;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 340 && mousePos.x <= 410) && (mousePos.y >= 290 && mousePos.y <= 360))
					{
						indexfrom.x = 1;
						indexfrom.y = 1;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 465 && mousePos.x <= 535) && (mousePos.y >= 290 && mousePos.y <= 360))
					{
						indexfrom.x = 1;
						indexfrom.y = 2;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 590 && mousePos.x <= 660) && (mousePos.y >= 290 && mousePos.y <= 360))
					{
						indexfrom.x = 1;
						indexfrom.y = 3;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 715 && mousePos.x <= 785) && (mousePos.y >= 290 && mousePos.y <= 360))
					{
						indexfrom.x = 1;
						indexfrom.y = 4;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 215 && mousePos.x <= 285) && (mousePos.y >= 435 && mousePos.y <= 485))
					{
						indexfrom.x = 2;
						indexfrom.y = 0;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 340 && mousePos.x <= 410) && (mousePos.y >= 435 && mousePos.y <= 485))
					{
						indexfrom.x = 2;
						indexfrom.y = 1;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 465 && mousePos.x <= 535) && (mousePos.y >= 435 && mousePos.y <= 485))
					{
						indexfrom.x = 2;
						indexfrom.y = 2;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 590 && mousePos.x <= 660) && (mousePos.y >= 435 && mousePos.y <= 485))
					{
						indexfrom.x = 2;
						indexfrom.y = 3;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 715 && mousePos.x <= 785) && (mousePos.y >= 435 && mousePos.y <= 485))
					{
						indexfrom.x = 2;
						indexfrom.y = 4;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 215 && mousePos.x <= 285) && (mousePos.y >= 540 && mousePos.y <= 610))
					{
						indexfrom.x = 3;
						indexfrom.y = 0;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 340 && mousePos.x <= 410) && (mousePos.y >= 540 && mousePos.y <= 610))
					{
						indexfrom.x = 3;
						indexfrom.y = 1;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 465 && mousePos.x <= 535) && (mousePos.y >= 540 && mousePos.y <= 610))
					{
						indexfrom.x = 3;
						indexfrom.y = 2;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 590 && mousePos.x <= 660) && (mousePos.y >= 540 && mousePos.y <= 610))
					{
						indexfrom.x = 3;
						indexfrom.y = 3;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 715 && mousePos.x <= 785) && (mousePos.y >= 540 && mousePos.y <= 610))
					{
						indexfrom.x = 3;
						indexfrom.y = 4;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 215 && mousePos.x <= 285) && (mousePos.y >= 665 && mousePos.y <= 735))
					{
						indexfrom.x = 4;
						indexfrom.y = 0;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 340 && mousePos.x <= 410) && (mousePos.y >= 665 && mousePos.y <= 735))
					{
						indexfrom.x = 4;
						indexfrom.y = 1;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 465 && mousePos.x <= 535) && (mousePos.y >= 665 && mousePos.y <= 735))
					{
						indexfrom.x = 4;
						indexfrom.y = 2;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 590 && mousePos.x <= 660) && (mousePos.y >= 665 && mousePos.y <= 735))
					{
						indexfrom.x = 4;
						indexfrom.y = 3;
						flag = 0;
						continue;
					}
					if ((mousePos.x >= 715 && mousePos.x <= 785) && (mousePos.y >= 665 && mousePos.y <= 735))
					{
						indexfrom.x = 4;
						indexfrom.y = 4;
						flag = 0;
						continue;
					}
				}
				else
				{
					sf::Vector2i mousePos = sf::Mouse::getPosition(window);
					if ((mousePos.x >= 215 && mousePos.x <= 285) && (mousePos.y >= 165 && mousePos.y <= 235))
					{
						indexto.x = 0;
						indexto.y = 0;
						flag = 1;
						
					}
					if ((mousePos.x >= 340 && mousePos.x <= 410) && (mousePos.y >= 165 && mousePos.y <= 235))
					{
						indexto.x = 0;
						indexto.y = 1;
						flag = 1;
						
					}
					if ((mousePos.x >= 465 && mousePos.x <= 535) && (mousePos.y >= 165 && mousePos.y <= 235))
					{
						indexto.x = 0;
						indexto.y = 2;
						flag = 1;
					
					}
					if ((mousePos.x >= 590 && mousePos.x <= 660) && (mousePos.y >= 165 && mousePos.y <= 235))
					{
						indexto.x = 0;
						indexto.y = 3;
						flag = 1;
						
					}
					if ((mousePos.x >= 715 && mousePos.x <= 785) && (mousePos.y >= 165 && mousePos.y <= 235))
					{
						indexto.x = 0;
						indexto.y = 4;
						flag = 1;
						
					}
					if ((mousePos.x >= 215 && mousePos.x <= 285) && (mousePos.y >= 290 && mousePos.y <= 360))
					{
						indexto.x = 1;
						indexto.y = 0;
						flag = 1;
						
					}
					if ((mousePos.x >= 340 && mousePos.x <= 410) && (mousePos.y >= 290 && mousePos.y <= 360))
					{
						indexto.x = 1;
						indexto.y = 1;
						flag = 1;
						
					}
					if ((mousePos.x >= 465 && mousePos.x <= 535) && (mousePos.y >= 290 && mousePos.y <= 360))
					{
						indexto.x = 1;
						indexto.y = 2;
						flag = 1;
						
					}
					if ((mousePos.x >= 590 && mousePos.x <= 660) && (mousePos.y >= 290 && mousePos.y <= 360))
					{
						indexto.x = 1;
						indexto.y = 3;
						flag = 1;
						
					}
					if ((mousePos.x >= 715 && mousePos.x <= 785) && (mousePos.y >= 290 && mousePos.y <= 360))
					{
						indexto.x = 1;
						indexto.y = 4;
						flag = 1;
						
					}
					if ((mousePos.x >= 215 && mousePos.x <= 285) && (mousePos.y >= 415 && mousePos.y <= 485))
					{
						indexto.x = 2;
						indexto.y = 0;
						flag = 1;
						
					}
					if ((mousePos.x >= 340 && mousePos.x <= 410) && (mousePos.y >= 415 && mousePos.y <= 485))
					{
						indexto.x = 2;
						indexto.y = 1;
						flag = 1;
						
					}
					if ((mousePos.x >= 465 && mousePos.x <= 535) && (mousePos.y >= 415 && mousePos.y <= 485))
					{
						indexto.x = 2;
						indexto.y = 2;
						flag = 1;
						
					}
					if ((mousePos.x >= 590 && mousePos.x <= 660) && (mousePos.y >= 415 && mousePos.y <= 485))
					{
						indexto.x = 2;
						indexto.y = 3;
						flag = 1;
						
					}
					if ((mousePos.x >= 715 && mousePos.x <= 785) && (mousePos.y >= 415 && mousePos.y <= 485))
					{
						indexto.x = 2;
						indexto.y = 4;
						flag = 1;
						
					}
					if ((mousePos.x >= 215 && mousePos.x <= 285) && (mousePos.y >= 540 && mousePos.y <= 610))
					{
						indexto.x = 3;
						indexto.y = 0;
						flag = 1;
						
					}
					if ((mousePos.x >= 340 && mousePos.x <= 410) && (mousePos.y >= 540 && mousePos.y <= 610))
					{
						indexto.x = 3;
						indexto.y = 1;
						flag = 1;
						
					}
					if ((mousePos.x >= 465 && mousePos.x <= 535) && (mousePos.y >= 540 && mousePos.y <= 610))
					{
						indexto.x = 3;
						indexto.y = 2;
						flag = 1;
						
					}
					if ((mousePos.x >= 590 && mousePos.x <= 660) && (mousePos.y >= 540 && mousePos.y <= 610))
					{
						indexto.x = 3;
						indexto.y = 3;
						flag = 1;
						
					}
					if ((mousePos.x >= 715 && mousePos.x <= 785) && (mousePos.y >= 540 && mousePos.y <= 610))
					{
						indexto.x = 3;
						indexto.y = 4;
						flag = 1;
						
					}
					if ((mousePos.x >= 215 && mousePos.x <= 285) && (mousePos.y >= 665 && mousePos.y <= 735))
					{
						indexto.x = 4;
						indexto.y = 0;
						flag = 1;
					
					}
					if ((mousePos.x >= 340 && mousePos.x <= 410) && (mousePos.y >= 665 && mousePos.y <= 735))
					{
						indexto.x = 4;
						indexto.y = 1;
						flag = 1;
						
					}
					if ((mousePos.x >= 465 && mousePos.x <= 535) && (mousePos.y >= 665 && mousePos.y <= 735))
					{
						indexto.x = 4;
						indexto.y = 2;
						flag = 1;
						
					}
					if ((mousePos.x >= 590 && mousePos.x <= 660) && (mousePos.y >= 665 && mousePos.y <= 735))
					{
						indexto.x = 4;
						indexto.y = 3;
						flag = 1;
						
					}
					if ((mousePos.x >= 715 && mousePos.x <= 785) && (mousePos.y >= 665 && mousePos.y <= 735))
					{
						indexto.x = 4;
						indexto.y = 4;
						flag = 1;
						
					}
				}
				success=working(arr, indexfrom.x, indexfrom.y, indexto.x, indexto.y,tosss);
				if (success)
				{
					tossoncetext = 0;
					tosss *= -1;
				}
			}
		}
	}
}