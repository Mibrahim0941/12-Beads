#include"SFML/Graphics.hpp"
#include<SFML/Audio.hpp>
#include"functions.h"
#include<iostream>
using namespace std;
using namespace sf;
int menu(int board[][5])
{

	RenderWindow window(VideoMode(1600, 900), "Play Game?");
	Texture texture;
	texture.loadFromFile("menuu.png");
	Sprite background(texture);
	Music music;
	music.openFromFile("music.mp3");
	music.play();
	music.setLoop(true);
	while (window.isOpen())
	{
		
		sf::Event event;
		while (window.pollEvent(event))
		{
			Vector2i mousePos(0,0);
			if (event.type == Event::MouseButtonPressed)
			{
				if (event.mouseButton.button == Mouse::Left)
				{
					mousePos = Mouse::getPosition(window);
					//cout << mousePos.x << " " << mousePos.y;
				}
				if ((mousePos.x>581&&mousePos.x<1018)&&(mousePos.y>370&&mousePos.y<470))
				{
					window.close();
					return 1;
				}
				if ((mousePos.x > 581 && mousePos.x < 1018) && (mousePos.y > 485 && mousePos.y < 585))
				{
					window.close();
					return 2;
				}
				if ((mousePos.x > 581 && mousePos.x < 1018) && (mousePos.y > 605 && mousePos.y < 705))
				{
					return 0;
					window.close();
					music.pause();
					
				}
			}
			
		}
		window.draw(background);
		window.display();
	}
}