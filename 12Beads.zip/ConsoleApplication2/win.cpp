#include<SFML\Graphics.hpp>
#include<SFML/Audio.hpp>
#include"functions.h"
#include<iostream>
using namespace std;
using namespace sf;
void win(int whowon)
{
	int arr[5][5] = { 0 };
	RenderWindow window(VideoMode(1600, 900), "Play Game?");
	Texture texture1,texture2;
	texture1.loadFromFile("player1.png");
	texture2.loadFromFile("player2.png");
	Sprite background1(texture1);
	Sprite background2(texture2);
	Music music;
	music.openFromFile("win.mp3");
	music.play();
	//music.setLoop(true);
	while (window.isOpen())
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			Vector2i mousePos;
			if (event.type == Event::MouseButtonPressed)
			{
				if (event.mouseButton.button == Mouse::Left)
				{
					mousePos = Mouse::getPosition(window);
					cout << mousePos.x << " " << mousePos.y;
				}
				if ((mousePos.x > 568 && mousePos.x < 1032) && (mousePos.y>452&&mousePos.y<555))
				{
	                
					window.close();
					music.pause();
					main();
				}
				if ((mousePos.x > 568 && mousePos.x < 1032) && (mousePos.y > 596 && mousePos.y < 701))
				{
				    window.close();
					music.pause();
				}
			}

		}
		if (whowon == 1)
			window.draw(background1);
		else if (whowon == 2)
			window.draw(background2);
		window.display();
	}
}