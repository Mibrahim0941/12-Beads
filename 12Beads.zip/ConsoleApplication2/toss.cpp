#include<iostream>
#include<conio.h>
int toss()
{
    int random;
    srand(time(0));
    random = 1 + rand() % 2;
    if (random == 1)
    {
        random = -1;
    }
    else
        random = 1;
    return random;
}